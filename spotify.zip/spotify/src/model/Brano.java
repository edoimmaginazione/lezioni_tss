package model;

public class Brano {
	

	public int minuti;
	public int secondi;
	
	
	String autore;
	String titolo;
	String genere;	
	String durata; 
	
	public Brano(int minuti, int secondi, String autore, String titolo, String genere) {
		this.durata = minuti + ":" + secondi;
		this.autore = autore;
		this.titolo = titolo;
		this.genere = genere;
	}



	public static void play() {
		
		
	}
	
	
	
	public static void stampaInfo() {
		 System.out.println();
	      
		
	}
	
	
	
	
	
	

}
