/**
 * 
 */
/**
 * 
 */
module spotify {
}